@extends('layouts.admin')
@section('title', 'القضايا التنفيذية المحذوفة')
@section('main_title_content', 'قائمة القضايا التنفيذية المحذوفة')
@section('title_content', 'عرض المحذوفة')
@section('link_content')
    <a href="{{ route('executive-case.index') }}">قضايا تنفيذية</a>
@endsection
@section('content')
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title card_title_center">بيانات القضايا التنفيذية المحذوفة</h3>
            </div>
            <div class="overflow-auto card-body">
                @if (@isset($data) and !@empty($data) and count($data) > 0)
                    <table id="example2" class="table table-bordered table-hover">
                        <thead class="custom_thead">
                            <th>رقم القضية</th>
                            <th>الرقم الوطني</th>
                            <th>اسم المدعي</th>
                            <th>اسم المدعى عليه</th>
                            <th>رقم الملف</th>
                            <th>موقع التنفيذ</th>
                            <th>نوع التنفيذ</th>
                            <th>رقم التنفيذ</th>
                            <th>تاريخ التنفيذ</th>
                            <th>حالة التنفيذ</th>
                            <th>إضافة بواسطة</th>
                            <th>تعديل بواسطة</th>
                            <th>تاريخ الإنشاء</th>
                            <th>سبب الحذف</th>
                            <th>التحكم</th>
                        </thead>
                        <tbody>
                            @foreach ($data as $info)
                                <tr>
                                    <td>{{ $info->case_number }}</td>
                                    <td>{{ $info->national_id }}</td>
                                    <td>{{ $info->plaintiff_name }}</td>
                                    <td>{{ $info->defendant_name }}</td>
                                    <td>{{ $info->file_number ?? 'غير محدد' }}</td>
                                    <td>{{ $info->execution_location ?? 'غير محدد' }}</td>
                                    <td>{{ $info->execution_type ?? 'غير محدد' }}</td>
                                    <td>{{ $info->execution_number ?? 'غير محدد' }}</td>
                                    <td>{{ $info->execution_date ?? 'غير محدد' }}</td>
                                    <td>{{ $info->execution_status ?? 'غير محدد' }}</td>
                                    <td>{{ $info->creator->username ?? 'غير محدد' }}</td>
                                    <td>
                                        @if (@isset($info->updater->username))
                                            {{ $info->updater->username }}
                                        @else
                                            لم يتم التعديل
                                        @endif
                                    </td>
                                    <td>{{ $info->created_at->format('Y-m-d') }}</td>
                                    <td>{{ $info->delete_reason ?? 'غير محدد' }}</td>
                                    <td>
                                        <a href="{{ route('executive-case.restore', $info->id) }}" class="btn btn-success">استرجاع</a>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                @else
                    <div class="col-md-12">
                        <div class="text-center alert alert-info">
                            لا توجد بيانات محذوفة لعرضها.
                        </div>
                    </div>
                @endif
            </div>
        </div>
    </div>
@endsection 