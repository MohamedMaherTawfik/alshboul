@extends('layouts.admin')
@section('title', 'القضايا التنفيذية')
@section('main_title_content', 'قائمة القضايا التنفيذية')
@section('title_content', 'تعديل')
@section('link_content')
    <a href="{{ route('executive-case.index') }}">قضايا تنفيذية</a>
@endsection
@section('content')
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title card_title_center">تعديل بيانات القضية التنفيذية</h3>
            </div>
            <div class="card-body">
                <form action="{{ route('executive-case.update', $data->id) }}" method="post">
                    @csrf
                    <input type="hidden" name="updated_by" value="{{ Auth::user()->id }}">
                    
                    <div class="row">
                        <div class="form-group col-md-4">
                            <label for="">رقم القضية</label>
                            <input type="text" name="case_number" value="{{ old('case_number', $data->case_number) }}" class="form-control">
                            @error('case_number')
                                <small class="text-muted text-danger">{{ $message }}</small>
                            @enderror
                        </div>
                        <div class="form-group col-md-4">
                            <label for="">الرقم الوطني</label>
                            <input type="text" name="national_id" value="{{ old('national_id', $data->national_id) }}" class="form-control">
                            @error('national_id')
                                <small class="text-muted text-danger">{{ $message }}</small>
                            @enderror
                        </div>
                        <div class="form-group col-md-4">
                            <label for="">رقم الملف</label>
                            <input type="text" name="file_number" value="{{ old('file_number', $data->file_number) }}" class="form-control">
                            @error('file_number')
                                <small class="text-muted text-danger">{{ $message }}</small>
                            @enderror
                        </div>
                    </div>

                    <div class="row">
                        <div class="form-group col-md-6">
                            <label for="">اسم المدعي</label>
                            <input type="text" name="plaintiff_name" value="{{ old('plaintiff_name', $data->plaintiff_name) }}" class="form-control">
                            @error('plaintiff_name')
                                <small class="text-muted text-danger">{{ $message }}</small>
                            @enderror
                        </div>
                        <div class="form-group col-md-6">
                            <label for="">اسم المدعى عليه</label>
                            <input type="text" name="defendant_name" value="{{ old('defendant_name', $data->defendant_name) }}" class="form-control">
                            @error('defendant_name')
                                <small class="text-muted text-danger">{{ $message }}</small>
                            @enderror
                        </div>
                    </div>

                    <div class="row">
                        <div class="form-group col-md-4">
                            <label for="">موقع التنفيذ</label>
                            <input type="text" name="execution_location" value="{{ old('execution_location', $data->execution_location) }}" class="form-control">
                            @error('execution_location')
                                <small class="text-muted text-danger">{{ $message }}</small>
                            @enderror
                        </div>
                        <div class="form-group col-md-4">
                            <label for="">نوع التنفيذ</label>
                            <select name="execution_type" class="form-control">
                                <option value="">اختر نوع التنفيذ</option>
                                <option value="مالي" {{ old('execution_type', $data->execution_type) == 'مالي' ? 'selected' : '' }}>مالي</option>
                                <option value="غير مالي" {{ old('execution_type', $data->execution_type) == 'غير مالي' ? 'selected' : '' }}>غير مالي</option>
                            </select>
                            @error('execution_type')
                                <small class="text-muted text-danger">{{ $message }}</small>
                            @enderror
                        </div>
                        <div class="form-group col-md-4">
                            <label for="">رقم التنفيذ</label>
                            <input type="text" name="execution_number" value="{{ old('execution_number', $data->execution_number) }}" class="form-control">
                            @error('execution_number')
                                <small class="text-muted text-danger">{{ $message }}</small>
                            @enderror
                        </div>
                    </div>

                    <div class="row">
                        <div class="form-group col-md-4">
                            <label for="">تاريخ التنفيذ</label>
                            <input type="date" name="execution_date" value="{{ old('execution_date', $data->execution_date) }}" class="form-control">
                            @error('execution_date')
                                <small class="text-muted text-danger">{{ $message }}</small>
                            @enderror
                        </div>
                        <div class="form-group col-md-4">
                            <label for="">طريقة التنفيذ</label>
                            <select name="execution_method" class="form-control">
                                <option value="">اختر طريقة التنفيذ</option>
                                <option value="يدوي" {{ old('execution_method', $data->execution_method) == 'يدوي' ? 'selected' : '' }}>يدوي</option>
                                <option value="الكتروني" {{ old('execution_method', $data->execution_method) == 'الكتروني' ? 'selected' : '' }}>الكتروني</option>
                            </select>
                            @error('execution_method')
                                <small class="text-muted text-danger">{{ $message }}</small>
                            @enderror
                        </div>
                        <div class="form-group col-md-4">
                            <label for="">حالة التنفيذ</label>
                            <select name="execution_status" class="form-control">
                                <option value="">اختر حالة التنفيذ</option>
                                <option value="منفذ" {{ old('execution_status', $data->execution_status) == 'منفذ' ? 'selected' : '' }}>منفذ</option>
                                <option value="غير منفذ" {{ old('execution_status', $data->execution_status) == 'غير منفذ' ? 'selected' : '' }}>غير منفذ</option>
                            </select>
                            @error('execution_status')
                                <small class="text-muted text-danger">{{ $message }}</small>
                            @enderror
                        </div>
                    </div>

                    <div class="row">
                        <div class="form-group col-md-4">
                            <label for="">مصدر التنفيذ</label>
                            <select name="execution_source" class="form-control">
                                <option value="">اختر مصدر التنفيذ</option>
                                <option value="الصندوق" {{ old('execution_source', $data->execution_source) == 'الصندوق' ? 'selected' : '' }}>الصندوق</option>
                                <option value="الفرع" {{ old('execution_source', $data->execution_source) == 'الفرع' ? 'selected' : '' }}>الفرع</option>
                                <option value="مستند رسمي" {{ old('execution_source', $data->execution_source) == 'مستند رسمي' ? 'selected' : '' }}>مستند رسمي</option>
                                <option value="إجراء آخر" {{ old('execution_source', $data->execution_source) == 'إجراء آخر' ? 'selected' : '' }}>إجراء آخر</option>
                            </select>
                            @error('execution_source')
                                <small class="text-muted text-danger">{{ $message }}</small>
                            @enderror
                        </div>
                        <div class="form-group col-md-4">
                            <label for="">رقم المرجع</label>
                            <input type="text" name="reference_number" value="{{ old('reference_number', $data->reference_number) }}" class="form-control">
                            @error('reference_number')
                                <small class="text-muted text-danger">{{ $message }}</small>
                            @enderror
                        </div>
                        <div class="form-group col-md-4">
                            <label for="">تاريخ المرجع</label>
                            <input type="date" name="reference_date" value="{{ old('reference_date', $data->reference_date) }}" class="form-control">
                            @error('reference_date')
                                <small class="text-muted text-danger">{{ $message }}</small>
                            @enderror
                        </div>
                    </div>

                    <div class="row">
                        <div class="form-group col-md-6">
                            <label for="">رقم المحكمة أو الحكم</label>
                            <input type="text" name="court_or_ruling_number" value="{{ old('court_or_ruling_number', $data->court_or_ruling_number) }}" class="form-control">
                            @error('court_or_ruling_number')
                                <small class="text-muted text-danger">{{ $message }}</small>
                            @enderror
                        </div>
                        <div class="form-group col-md-6">
                            <label for="">اسم المحكمة أو الحكم</label>
                            <input type="text" name="court_or_ruling_name" value="{{ old('court_or_ruling_name', $data->court_or_ruling_name) }}" class="form-control">
                            @error('court_or_ruling_name')
                                <small class="text-muted text-danger">{{ $message }}</small>
                            @enderror
                        </div>
                    </div>

                    <div class="row">
                        <div class="form-group col-md-6">
                            <label for="">نسخة ملف التنفيذ</label>
                            <input type="text" name="execution_file_copy" value="{{ old('execution_file_copy', $data->execution_file_copy) }}" class="form-control">
                            @error('execution_file_copy')
                                <small class="text-muted text-danger">{{ $message }}</small>
                            @enderror
                        </div>
                        <div class="form-group col-md-6">
                            <label for="">الحالة</label>
                            <select name="status" class="form-control">
                                <option value="">اختر الحالة</option>
                                <option value="جديد" {{ old('status', $data->status) == 'جديد' ? 'selected' : '' }}>جديد</option>
                                <option value="مؤرشف" {{ old('status', $data->status) == 'مؤرشف' ? 'selected' : '' }}>مؤرشف</option>
                                <option value="ملغي" {{ old('status', $data->status) == 'ملغي' ? 'selected' : '' }}>ملغي</option>
                            </select>
                            @error('status')
                                <small class="text-muted text-danger">{{ $message }}</small>
                            @enderror
                        </div>
                    </div>

                    <div class="row">
                        <div class="form-group col-md-12">
                            <label for="">ملاحظات</label>
                            <textarea name="notes" class="form-control" rows="3">{{ old('notes', $data->notes) }}</textarea>
                            @error('notes')
                                <small class="text-muted text-danger">{{ $message }}</small>
                            @enderror
                        </div>
                    </div>

                    <div class="text-center col-md-12">
                        <button type="submit" class="btn btn-success">تعديل</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection 