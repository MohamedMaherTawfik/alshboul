<footer class="main-footer">
    <!-- To the right -->
    <div class="float-right d-none d-sm-inline">
        <b>Version</b> 3.0.5
    </div>
    <!-- Default to the left -->
    <strong>Copyright &copy; {{ date('Y') }} <a href="https://alshboul.metafortech.com">الشبول للمحاماة</a>.</strong>
    All rights
    reserved.
</footer>
